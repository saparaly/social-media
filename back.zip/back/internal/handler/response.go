package handler

import "net/http"

func newErrorResponse(w http.ResponseWriter, r *http.Request, statusCode int, message string) {
}
